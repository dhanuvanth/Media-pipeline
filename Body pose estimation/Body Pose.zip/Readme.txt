

========================================ABOUT SCRIPTS======================================================

global_var.py - It has all the global variables. You can tweak the values for colour, resolution, size.

main.py - Main source code file to run

verson.py - To check the version.

==================================== STEPS TO INSTALL AND RUN ===============================================

Step 1: Installation
    - Open the terminal
    - Type "pip install -r requirements"
    - Enter

Step 2: Check the versions
    - Type "python version.py"
    - Check the version
        - opencv = 4.5.2 or higher
        - numpy = 1.18.5 or higher

Step 3: Run the Script
    - Normal mode
        - Type "python main.py"
    - Debug mode
        - Type "python main.py --debug true"

=============================================================================================================

                                    		THANK YOU

=============================================================================================================