screenResolution = (640,480) # resolution
posePointsColor = (0,0,0)  # black
videoCam = 'video.mp4'  # primary camera
rectangleScale = [10, 10] # point size scaling [w, h]