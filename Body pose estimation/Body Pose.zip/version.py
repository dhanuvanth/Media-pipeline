import cv2
import numpy as np

print(cv2.__version__)
print(np.__version__)